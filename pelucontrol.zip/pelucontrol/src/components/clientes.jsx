//Datos simulados
export const clientesIniciales = [
  { id: 1, nombre: "Laura González", telefono: "644123123" },
  { id: 2, nombre: "Carlos Ruiz", telefono: "655321321" },
  { id: 3, nombre: "Marta Pérez", telefono: "699112233" },
];
