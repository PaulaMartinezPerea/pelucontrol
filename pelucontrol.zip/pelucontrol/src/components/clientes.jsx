//Datos simulados
export const clientesIniciales = [
  { id: 1, nombre: "Laura González", telefono: "644123123" },
  { id: 2, nombre: "Carlos Ruiz", telefono: "655321321" },
  { id: 3, nombre: "Marta Pérez", telefono: "699112233" },
  //Añadidos por mi:
  { id: 4, nombre: "Ana López", telefono: "622334455" },
  { id: 5, nombre: "Javier Fernández", telefono: "633445566" },
  { id: 6, nombre: "Lucía Martínez", telefono: "644556677" },
  { id: 7, nombre: "David Sánchez", telefono: "655667788" },
  { id: 8, nombre: "Sofía Ramírez", telefono: "666778899" },
  { id: 9, nombre: "Miguel Torres", telefono: "677889900" },
  { id: 10, nombre: "Elena Moreno", telefono: "688990011" },
];
