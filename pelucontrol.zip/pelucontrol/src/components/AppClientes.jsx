import React, { useState } from 'react';
import { clientesIniciales } from './clientes';

function AppClientes() {
  const [busqueda, setBusqueda] = useState(''); //Estado del campo de búsqueda

  //Filtrar clientes por nombre o teléfono
  const clientesFiltrados = clientesIniciales.filter(cliente =>
    cliente.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
    cliente.telefono.includes(busqueda)
  );

  return (
    <div>
      <h1>LISTA DE CLIENTES</h1>
      
      {/*Campo de búsqueda*/}
      <input
        type="text"
        placeholder="Buscar por nombre o teléfono..."
        value={busqueda}
        onChange={e => setBusqueda(e.target.value)}
      />

      {/*Lista de clientes*/}
      {clientesFiltrados.length > 0 ? (
        <ul>
          {clientesFiltrados.map(cliente => (
            <li key={cliente.id}>
              <strong>{cliente.nombre}</strong> - {cliente.telefono}
            </li>
          ))}
        </ul>
      ) : (
        <p>No se encontraron resultados.</p>
      )}
    </div>
  );
}

export default AppClientes;
